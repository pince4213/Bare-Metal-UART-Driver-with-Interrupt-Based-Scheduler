
#include "uart.h"

#define UART_BASE 0x40011000U
#define UART_SR   (*(volatile uint32_t *)(UART_BASE + 0x00))
#define UART_DR   (*(volatile uint32_t *)(UART_BASE + 0x04))
#define UART_BRR  (*(volatile uint32_t *)(UART_BASE + 0x08))
#define UART_CR1  (*(volatile uint32_t *)(UART_BASE + 0x0C))

#define TXE (1 << 7)
#define RXNE (1 << 5)
#define UE  (1 << 13)
#define TE  (1 << 3)
#define RE  (1 << 2)

void uart_init(uint32_t baudrate)
{
    (void)baudrate;  // Simplified example (board-specific clock config required)
    UART_BRR = 0x0045; 
    UART_CR1 |= (UE | TE | RE);
}

void uart_send(char c)
{
    while (!(UART_SR & TXE));
    UART_DR = c;
}

void uart_send_string(const char *str)
{
    while (*str)
    {
        uart_send(*str++);
    }
}
