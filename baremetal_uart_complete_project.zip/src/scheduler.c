
#include "scheduler.h"
#include "timer.h"

#define MAX_TASKS 5

typedef struct {
    task_func_t task;
    uint32_t period;
    uint32_t last_run;
} task_t;

static task_t tasks[MAX_TASKS];
static uint8_t task_count = 0;

void scheduler_init(void)
{
    task_count = 0;
}

void scheduler_add_task(task_func_t task, uint32_t period_ms)
{
    if (task_count < MAX_TASKS)
    {
        tasks[task_count].task = task;
        tasks[task_count].period = period_ms;
        tasks[task_count].last_run = 0;
        task_count++;
    }
}

void scheduler_run(void)
{
    for (uint8_t i = 0; i < task_count; i++)
    {
        if ((system_ticks - tasks[i].last_run) >= tasks[i].period)
        {
            tasks[i].last_run = system_ticks;
            tasks[i].task();
        }
    }
}
