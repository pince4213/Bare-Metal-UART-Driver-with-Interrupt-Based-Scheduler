
#ifndef TIMER_H
#define TIMER_H

void timer_init(void);
extern volatile unsigned long system_ticks;

#endif
