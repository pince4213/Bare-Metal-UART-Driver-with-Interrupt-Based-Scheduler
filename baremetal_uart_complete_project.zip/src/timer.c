
#include "timer.h"

volatile unsigned long system_ticks = 0;

void SysTick_Handler(void)
{
    system_ticks++;
}

void timer_init(void)
{
    volatile unsigned int *SYST_CSR = (unsigned int *)0xE000E010;
    volatile unsigned int *SYST_RVR = (unsigned int *)0xE000E014;
    volatile unsigned int *SYST_CVR = (unsigned int *)0xE000E018;

    *SYST_RVR = 72000 - 1; 
    *SYST_CVR = 0;
    *SYST_CSR = 7; 
}
