
#ifndef SCHEDULER_H
#define SCHEDULER_H

#include <stdint.h>

typedef void (*task_func_t)(void);

void scheduler_init(void);
void scheduler_add_task(task_func_t task, uint32_t period_ms);
void scheduler_run(void);

#endif
