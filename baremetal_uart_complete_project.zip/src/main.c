
#include "uart.h"
#include "timer.h"
#include "scheduler.h"

void task1(void)
{
    uart_send_string("Task1 running\r\n");
}

void task2(void)
{
    uart_send_string("Task2 running\r\n");
}

int main(void)
{
    uart_init(921600);
    timer_init();
    scheduler_init();

    scheduler_add_task(task1, 1000);
    scheduler_add_task(task2, 2000);

    while (1)
    {
        scheduler_run();
    }
}
