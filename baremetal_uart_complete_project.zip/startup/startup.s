
.syntax unified
.cpu cortex-m3
.thumb

.global _start
.global Reset_Handler

.section .isr_vector
.word 0x20005000
.word Reset_Handler
.word 0
.word 0
.word 0
.word 0
.word 0
.word 0
.word 0
.word 0
.word 0
.word 0
.word 0
.word 0
.word 0
.word SysTick_Handler

.section .text
Reset_Handler:
    bl main
    b .
