
#ifndef CIRCULAR_BUFFER_H
#define CIRCULAR_BUFFER_H

#include <stdint.h>

#define BUFFER_SIZE 128

typedef struct {
    char buffer[BUFFER_SIZE];
    uint16_t head;
    uint16_t tail;
} circular_buffer_t;

void cb_init(circular_buffer_t *cb);
void cb_push(circular_buffer_t *cb, char data);
char cb_pop(circular_buffer_t *cb);

#endif
