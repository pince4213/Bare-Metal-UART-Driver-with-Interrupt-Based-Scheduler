
#ifndef UART_H
#define UART_H

#include <stdint.h>

void uart_init(uint32_t baudrate);
void uart_send(char c);
char uart_receive(void);

#endif
