
#include "uart.h"

#define UART_BASE 0x40011000
#define UART_DR   (*(volatile uint32_t *)(UART_BASE + 0x04))
#define UART_SR   (*(volatile uint32_t *)(UART_BASE + 0x00))

void uart_init(uint32_t baudrate)
{
    // Simplified example (board-specific config required)
}

void uart_send(char c)
{
    while (!(UART_SR & (1 << 7)));
    UART_DR = c;
}

char uart_receive(void)
{
    while (!(UART_SR & (1 << 5)));
    return (char)UART_DR;
}
