
#include "circular_buffer.h"

void cb_init(circular_buffer_t *cb)
{
    cb->head = 0;
    cb->tail = 0;
}

void cb_push(circular_buffer_t *cb, char data)
{
    cb->buffer[cb->head++] = data;
    cb->head %= BUFFER_SIZE;
}

char cb_pop(circular_buffer_t *cb)
{
    char data = cb->buffer[cb->tail++];
    cb->tail %= BUFFER_SIZE;
    return data;
}
