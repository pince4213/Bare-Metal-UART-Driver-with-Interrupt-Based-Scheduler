
#include "uart.h"
#include "timer.h"
#include "scheduler.h"

int main(void)
{
    uart_init(921600);
    timer_init();
    scheduler_init();

    while (1)
    {
        scheduler_run();
    }
}
